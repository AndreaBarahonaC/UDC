##----------------------------------------------------------------------------#
## Pr�cticas de DoE con R ----------------------------------------------------#
##----------------------------------------------------------------------------#

# �NDICE
# 1. Ejemplos de pruebas ANOVA
# 2. Dise�os Factoriales
# 3. Dise�os Factoriales fraccionados
# 4. Estudios interlaboratorio
# 5. Ejemplos de aplicaci�n y casos de estudio de DoE

##----------------------------------------------------------------------------#
#  1.- Ejemplos de Pruebas ANOVA
##----------------------------------------------------------------------------#

#- 1.1. Ejemplo de la resistencia a la tracci�n de aceros-------------------------#

 traccion=c(39, 33, 39, 35, 32,
            36, 40, 35, 30, 29,
            33, 33, 36, 26, 35)
 
 Hormigon=as.factor(c(rep("A",5),rep("B",5),rep("C",5)))

 boxplot(split(traccion,Hormigon),xlab='Tipo de hormig�n',
         ylab='Resistencia a la tracci�n',col=terrain.colors(3))
 
 anovatraccion<-aov(traccion~Hormigon)
 summary(aov(anovatraccion))              # Construye la tabla ANOVA
 
 # Diagn�sis de las hip�tesis del modelo: 
 # Independencia, normalidad, homocedasticidad
 
 res<-residuals(anovatraccion)            # Se calculan los residuos.
 yh<-fitted(anovatraccion)
 plot(yh,res)
 abline(h=0,col=2,lty=2)
 
 shapiro.test(res)       # Prueba de normalidad, los residuos son normales
 qqnorm(res)
 qqline(res)
 
 library(car)			       #Para poder hacer la prueba de LEVENE se necesita
                         #la librer�a CAR que se descarga de la p�gina del R.
 leveneTest(traccion,Hormigon)    # Prueba de Levene para homogeneidad de varianzas
                                  # Residuos homoced�sticos.
 bartlett.test(traccion,Hormigon) # Prueba de Bartlett para homogeneidad de varianzas
                                  # Residuos homoced�sticos.   
 # Diagn�sis gr�fica del modelo:
 par(mfrow = c(2, 2), oma = c(0, 0, 2, 0))
 plot(anovatraccion)
 
#-1.2. Laboratorios. Variable respuesta: peso------------------------------------#

laboratorio<-c(rep(1,12),rep(2,12),rep(3,12),rep(4,12))
laboratorio<-as.factor(laboratorio)
peso<-c(0.25, 0.27, 0.22, 0.30, 0.27, 0.28, 0.32, 0.24, 0.31, 0.26, 0.21, 0.28,
0.19, 0.25, 0.27, 0.24, 0.18, 0.26, 0.28, 0.24, 0.25, 0.20, 0.21, 0.19,
0.18, 0.28, 0.21, 0.23, 0.25, 0.20, 0.27, 0.19, 0.24, 0.22, 0.29, 0.16,
0.23, 0.30, 0.28, 0.28, 0.24, 0.34, 0.20, 0.18, 0.24, 0.28, 0.22, 0.21)

boxplot(split(peso,laboratorio),xlab='Laboratorios',ylab='Peso de estaño')
anovapeso<-aov(peso~ laboratorio)
summary(aov(peso~laboratorio))  # Construye la tabla ANOVA
res<-residuals(anovapeso)            # Se calculan los residuals.
yh<-fitted(anovapeso)
plot(yh,res)
abline(h=0)

shapiro.test(res)                            # Prueba de normalidad
qqnorm(res)
qqline(res)
library(car)			       #Para poder hacer la prueba de LEVENE se necesita
			                   #la librer�?a CAR que se descarga de la página del R.
leveneTest(peso,laboratorio)         # Prueba de Levene para homogeneidad de varianzas
bartlett.test(peso,laboratorio)        # Prueba de Bartlett para homogeneidad de varianzas


##-1.3. Ejemplo con los datos de Morley sobre velocidad de la luz -----------------#

luz<-morley
luz$Expt <- factor(luz$Expt)
luz$Run <- factor(luz$Run)
summary(luz)
attach(luz)

plot(Expt, Speed, main="Velocidad de la luz", xlab="Experimento Número")

fm <- aov(Speed ~ Run + Expt, data=luz)
summary(fm)
names(fm)
fm$coef

summary(fm)
names(fm)
fm$coef

par(mfrow=c(2,2))
plot(fm)
windows()
rm(fm)

## Otro diseño con el test de Tuckey para tensión de la lana (dos tipos diferentes) en un telar 
## 54 observaciones en 3 telares con dos tipo de lana (medida de roturas)
data(warpbreaks)
summary(fm1 <- aov(breaks ~ wool + tension, data = warpbreaks))
TukeyHSD(fm1, "tension", ordered = TRUE)            
plot(TukeyHSD(fm1, "tension"))


#-----------------------------------------------------------------------------#
# 2. DISE�OS FACTORIALES ------------------------------------------------------# 
#-----------------------------------------------------------------------------#

#-2.1. Fiabilidad Resina epoxi --------------------------------------------------# 

# Base de datos y construcci�n del esquema:

Inclinacion=factor(c(0,1,0,1,0,1,0,1))
Grosor=factor(c(0,0,1,1,0,0,1,1))
Postcurado=factor(c(0,0,0,0,1,1,1,1))
Compresiones=c(79,97,75,92,64,84,73,90)

library(qualityTools)

diseno.frac = fracDesign(k = 3)
names(diseno.frac)=c("Inclinacion","Grosor","Postcurado")
diseno.frac
Compresiones_b=c(92,75,97,64,84,73,90,79)
response(diseno.frac)=
  data.frame(Compresiones=Compresiones_b)
summary(diseno.frac)

## Efectos principales:
effectPlot(diseno.frac, classic = TRUE)

# Alternativa:
par(mfrow=c(1,3))

Efecto.I=data.frame(Inclinacion,Compresiones)
plot.design(Efecto.I,fun="mean",main="Inclinacion",xlab="",
            ylab=list("Compresiones",cex=1.4))
Efecto.G=data.frame(Grosor,Compresiones)
plot.design(Efecto.G,fun="mean",main="Grosor",xlab="",
            ylab=list("Compresiones",cex=1.4))
Efecto.P=data.frame(Postcurado,Compresiones)
plot.design(Efecto.P,fun="mean",main="Postcuarado",xlab="",
            ylab=list("Compresiones",cex=1.4))


## Efectos de las interacciones:
windows()
interactionPlot(diseno.frac)

#Alternativa

par(mfrow=c(2,2))
interaction.plot(Inclinacion,Grosor,Compresiones,main="Interacci?n I - G",
                 xlab=list("I",cex=1.4))

interaction.plot(Inclinacion,Postcurado,Compresiones,main="Interacci?n I - P",
                 xlab=list("I",cex=1.4))

interaction.plot(Grosor,Postcurado,Compresiones,main="Interacci?n G - P",
                 xlab=list("G",cex=1.4))
par(mfrow=c(1,1))

# Hay interacci�n entre el grosor y el postcurado

## Gr�fico de Pareto:
#[El gr�fico de Pareto muestra los valores absolutos de los efectos 
# estandarizados desde el efecto m�s grande hasta el efecto m�s 
# peque�o. Los efectos estandarizados son estad�sticos que se
# distribuyen como una t-student. As� se contrasta la hip�tesis 
# nula de que el efecto es 0. 
# El gr�fico tambi�n traza una l�nea de referencia para indicar 
# qu� efectos son estad�sticamente significativos.]

windows()
paretoPlot(diseno.frac,main="Diagrama de Pareto de los efectos",abs=T,
           xlab=list("Factores",cex=1.4),
           las=1,col=2:6,alpha=0.05)

# Interpretaci�n: Se usa el diagrama de Pareto para determinar la 
# magnitud y la importancia de los efectos. En el gr�fico de 
# Pareto, las barras que cruzan la l�nea de referencia hacen 
# referencia a efectos estad�sticamente significativos. 
# Si el diese�o no es replicado, se utiliza el m�todo de Lenth 
# para dibujar una l�nea de referencia correspondiente al alpha
# (mediante el "Error pseudo est�ndar (PSE)" de Lenth). 
# Los efectos de inclinaci�n, postcurado e interacci�n grosor
# postcurado son significativos.

## ANALISIS DEL DISE�O CON LA TABLA ANOVA
# Otra forma de identificar los efectos significativos
analisis.disen=aov(Compresiones~(Inclinacion + Grosor + Postcurado))
summary(analisis.disen)

analisis.disen=aov(Compresiones~Inclinacion + Grosor * Postcurado)
summary(analisis.disen)

## Gr�fica de probabilidad normal:

# Debido a que el gr�fico de Pareto muestra el valor 
# absoluto de los efectos, puede determinar qu� efectos 
# son grandes, pero no puede determinar qu� efectos 
# aumentan o disminuyen la respuesta. �sese la gr�fica de 
# probabilidad normal de los efectos estandarizados para 
# examinar la magnitud y direcci�n de los efectos.

# *La gr�fica de probabilidad normal de los efectos muestra
# los efectos estandarizados relativos a una l�nea de 
# ajuste de distribuci�n para el caso en el que todos los 
# efectos son 0. Los efectos estandarizados son 
# t-estad�sticos que contrastan la hip�tesis nula de que 
# el efecto es 0. 
# *Los efectos positivos aumentan la respuesta cuando la 
# configuraci�n cambia del valor bajo del factor al valor 
# alto. 
# *Los efectos negativos disminuyen la respuesta cuando su 
# configuraci�n cambia del valor bajo del factor al alto 
# *Los efectos m�s all� de 0 en el eje x tienen mayor 
# magnitud. Los efectos m�s all� de 0 son estad�sticamente
# m�s significativos.

normalPlot(diseno.frac)

# Inclinaci�n y la interacci�n Inclinaci�n:Postcurado 
# tienen efecto positivo sobre la respuesta.
# El postcurado tiene efecto negativo.

# Superficie de respuesta para ver la relaci�n entre
# inclinaci�n y postcurado

# Visualizaci�n con un mapa de contorno y una superficie
# de respuesta:
par(mfrow = c(1,2))
wirePlot(A, C, Compresiones, data = diseno.frac)
contourPlot(A, C, Compresiones, data = diseno.frac)

 
 #-----------------------------------------------------------------------------#
 # 3. DISE�OS FACTORIALES FRACCIONADOS ----------------------------------------# 
 #-----------------------------------------------------------------------------#
 
# Se ajusta el modelo param�trico de Paris, dependiente de los par�metros C y m
# para estimar la longitud de grietas en un material en funci�n del n�mero
# de ciclos de esfuerzos a fatiga.
## Se tratar�a de ver si unos par�metros de un modelo de fiabilidad (prueba de fatiga tipo Paris)
## son significativos a la par que se analiza el posible efecto de la interacci�n.

##        EJEMPLO de DISE�O FRACCIONADO 1/4

 library(qualityTools)

##     MATRIZ DE BASE DE DATOS: valores ajustados

S2m=c(0.1,0.5,0.1,0.5,0.1,0.5,0.1,0.5)
SCm=c(-0.09,-0.09,-0.02,-0.02,-0.09,-0.09,-0.02,-0.02)
S2C=c(0.1,0.1,0.1,0.1,0.5,0.5,0.5,0.5)
m=c(4,3,3,4,4,3,3,4)
C=c(6,5,6,5,5,6,5,6)

S2_m=factor(S2m); S_Cm=factor(SCm);S2_C=factor(S2C);m=factor(m);C=factor(C)

## RESPUESTA DE LAS DISTANCIAS L2 DE LAS OCHO COMBINACIONES

resp.lme.L2=c(0.001326,0.001648,0.000626,0.002624,0.005023,0.002590,0.003786,
              0.003949)

## DIAGRAMA DE PARETO DE LOS EFECTOS SIGNIFICATIVOS


diseno.frac = fracDesign(k = 5, gen = c("D=AB","E=AC"))
names(diseno.frac)=c("var(m)","cov(C,m)","var(C)","m","C")
response(diseno.frac)=data.frame(resp.L2=c(0.002624,0.000626,0.001648,0.005023,
                                           0.002590,0.003786,0.003949,0.001326))

paretoPlot(diseno.frac,main="Diagrama de Pareto de los efectos",abs=T,
           xlab=list("Efectos",cex=1.4),ylab=list(expression(L[2]),cex=1.2),
           las=1,col=2:6)

## ANALISIS DEL DISEÑO CON LA TABLA ANOVA
analisis.disen=aov(resp.lme.L2~(S2_m + S_Cm + S2_C + m + C))
summary(analisis.disen)
#             Df    Sum Sq   Mean Sq F value  Pr(>F)
#S2_m         1 0.000e+00 0.000e+00   0.006 0.94647
#S_Cm         1 2.000e-08 2.000e-08   0.364 0.60756
#S2_C         1 1.041e-05 1.041e-05 191.348 0.00519 **
#m            1 2.281e-06 2.281e-06  41.948 0.02302 *
#C            1 2.634e-06 2.634e-06  48.426 0.02003 *
#Residuals    2 1.090e-07 5.400e-08

#Signif. codes:  0 ?***? 0.001 ?**? 0.01 ?*? 0.05 ?.? 0.1 ? ? 1

## GR?FICOS DE EEFCTOS PRINCIPALES+
            ylab=list("L2",cex=1.4))

Efecto.C=data.frame(C,resp.lme.L2)
plot.design(Efecto.C,fun="mean",main="Factor C",xlab="",
            ylab=list("L2",cex=1.4))

par(mfrow=c(1,1))

##  ESTRUCTURA DE ALIAS

## A=S2_m ; B=S_Cm ; C=S2_C ; D=m ; E= C

## I + ABD + ACE + BCDE

## A + BD + CE + ABCDE
## B + AD + CDE + ABCE
## C + AE + BDE + ABCD    * EFECTO SIGNIFICATIVO C
## D + AB + BCE + ACDE    * EFECTO SIGNIFICATIVO D
## E + AC + BCD + ABDE    * EFECTO SIGNIFICATIVO E
## BC + DE + ABE + ACD
## BE + CD + ABC + ADE

## GR?FICOS DE EFECTOS PRINCIPALES SIGNIFICATIVOS

par(mfrow=c(2,2))
interaction.plot(S2_m,C,resp.lme.L2,main="Interacci?n var(m) - C",
                 ylab=expression(L[2]),xlab=list("var(m)",cex=1.4))

interaction.plot(S2_m,S_Cm,resp.lme.L2,main="Interacci?n var(m) - cov(C,m)",
                 ylab=expression(L[2]),xlab=list("var(m)",cex=1.4))

interaction.plot(S2_m,S2_C,resp.lme.L2,main="Interacci?n var(m) - var(C)",
                 ylab=expression(L[2]),xlab=list("var(m)",cex=1.4))
par(mfrow=c(1,1))



## MODELO LINEAL

model.lm=lm(resp.lme.L2~(S2_m +S_Cm +S2_C +m + C))
anova(model.lm) # Es el mismo resumen de la tabla ANOVA

summary(model.lm)
## p-value: 0.01751   es significativo el modelo al 95%
## y los coeficientes significativos del modelo coinciden con los de latabla ANOVA

#Coefficients:
#              Estimate Std. Error t value Pr(>|t|)
#(Intercept)  0.0015398  0.0002020   7.624  0.01677 *
#S2_m0.5      0.0000125  0.0001649   0.076  0.94647
#S_Cm-0.02    0.0000995  0.0001649   0.603  0.60756
#S2_C0.5      0.0022810  0.0001649  13.833  0.00519 **
#m4           0.0010680  0.0001649   6.477  0.02302 *
#C6          -0.0011475  0.0001649  -6.959  0.02003 *
#---
#Signif. codes:  0 ?***? 0.001 ?**? 0.01 ?*? 0.05 ?.? 0.1 ? ? 1

#Residual standard error: 0.0002332 on 2 degrees of freedom
#Multiple R-squared:  0.993,     Adjusted R-squared:  0.9754
#F-statistic: 56.42 on 5 and 2 DF,  p-value: 0.01751


## RESIDUOS DEL MODELO

plot(rstandard(model.lm),main="Comportamiento de los residuos estándar",
     ylab=list("Residuos est?ndar",cex=1.2),xlab="?ndice",ylim=c(-2,2),pch=20,
     cex=2,col=4)
# Est?n dentro del intervalo de -2 a 2

## PREDICCIONES DEL MODELO PARA IDENTIFICAR EL NIVEL ÓPTIMO DE var(m)

factorA=factor(c(0.1,0.5)) ; factorB=factor(c(-0.02,-0.02))
factorC=factor(c(0.1,0.1)) ; factorD=factor(c(3,3))
factorE=factor(c(6,6))

pred.model=predict(model.lm,newdata=data.frame(S2_m=factorA,S_Cm=factorB,
                                               S2_C=factorC, m=factorD,
                                               C=factorE),level=0.95,
                   interval="confidence")
pred.model

#         fit           lwr         upr
#1 0.00049175 -0.0003772015 0.001360701     # óptimo es en 0.1 para
#2 0.00050425 -0.0003647015 0.001373201     # var(m)=S2_m  pues tiene
# el menor fit



## COMBINACIÓN ÓPTIMA PARA EL DISEÑO EXPERIMENTAL FRACCIONADO CON RESPUESTA L2

# C = 6  , m = 3 , S2_C = 0.1 , S2_m = 0.1 , S_Cm = -0.02

# C = 6 , m = 3 , var(C) = 0.1 , var(m)= 0.1 , cov(C,m) = -0.02


#-----------------------------------------------------------------------------#

#-----------------------------------------------------------------------------#
# 4. ESTUDIOS INTERLABORATORIO (CASO PARTICULAR DE DOE Y ESTUDIOS R&R) -------# 
#    Ejemplo de aplicaci�n de la norma ASTM691                         -------#
#-----------------------------------------------------------------------------#


laboratorio<-read.table("c:/laboratorio.txt",header=T,dec=",",sep="")

attach(laboratorio)


############### Medias por Laboratorio y Nivel de Concentración (y) ##################

a1<-mean(A[Laboratorios=="1"])
a2<-mean(A[Laboratorios=="2"])
a3<-mean(A[Laboratorios=="3"])
a4<-mean(A[Laboratorios=="4"])
a5<-mean(A[Laboratorios=="5"])
a6<-mean(A[Laboratorios=="6"])
a7<-mean(A[Laboratorios=="7"])
a8<-mean(A[Laboratorios=="8"])

b1<-mean(B[Laboratorios=="1"]); b2<-mean(B[Laboratorios=="2"]); b3<-mean(B[Laboratorios=="3"]); b4<-mean(B[Laboratorios=="4"]); b5<-mean(B[Laboratorios=="5"]); b6<-mean(B[Laboratorios=="6"]); b7<-mean(B[Laboratorios=="7"]); b8<-mean(B[Laboratorios=="8"])

c1<-mean(C[Laboratorios=="1"]); c2<-mean(C[Laboratorios=="2"]); c3<-mean(C[Laboratorios=="3"]); c4<-mean(C[Laboratorios=="4"]); c5<-mean(C[Laboratorios=="5"]); c6<-mean(C[Laboratorios=="6"]); c7<-mean(C[Laboratorios=="7"]); c8<-mean(C[Laboratorios=="8"])

d1<-mean(D[Laboratorios=="1"]); d2<-mean(D[Laboratorios=="2"]); d3<-mean(D[Laboratorios=="3"]); d4<-mean(D[Laboratorios=="4"]); d5<-mean(D[Laboratorios=="5"]); d6<-mean(D[Laboratorios=="6"]); d7<-mean(D[Laboratorios=="7"]); d8<-mean(D[Laboratorios=="8"])

e1<-mean(E[Laboratorios=="1"]); e2<-mean(E[Laboratorios=="2"]); e3<-mean(E[Laboratorios=="3"]); e4<-mean(E[Laboratorios=="4"]); e5<-mean(E[Laboratorios=="5"]); e6<-mean(E[Laboratorios=="6"]); e7<-mean(E[Laboratorios=="7"]); e8<-mean(E[Laboratorios=="8"])


y<-data.frame(cbind("A"=c(a1,a2,a3,a4,a5,a6,a7,a8),"B"=c(b1,b2,b3,b4,b5,b6,b7,b8),"C"=c(c1,c2,c3,c4,c5,c6,c7,c8),"D"=c(d1,d2,d3,d4,d5,d6,d7,d8),"E"=c(e1,e2,e3,e4,e5,e6,e7,e8)));y


############################# Medias generales (m) #############################

m<-data.frame(cbind(mean(A),mean(B),mean(C),mean(D),mean(E)))
colnames(m)<-c("A","B","C","D","E")
m


################ Desviaciones T�?picas por Laboratorio y Nivel de Concentración (s_i) ####################

sa1<-sd(A[Laboratorios=="1"]); sa2<-sd(A[Laboratorios=="2"]); sa3<-sd(A[Laboratorios=="3"]); sa4<-sd(A[Laboratorios=="4"]); sa5<-sd(A[Laboratorios=="5"]); sa6<-sd(A[Laboratorios=="6"]); sa7<-sd(A[Laboratorios=="7"]); sa8<-sd(A[Laboratorios=="8"])

sb1<-sd(B[Laboratorios=="1"]); sb2<-sd(B[Laboratorios=="2"]); sb3<-sd(B[Laboratorios=="3"]); sb4<-sd(B[Laboratorios=="4"]); sb5<-sd(B[Laboratorios=="5"]); sb6<-sd(B[Laboratorios=="6"]); sb7<-sd(B[Laboratorios=="7"]); sb8<-sd(B[Laboratorios=="8"])

sc1<-sd(C[Laboratorios=="1"]); sc2<-sd(C[Laboratorios=="2"]); sc3<-sd(C[Laboratorios=="3"]); sc4<-sd(C[Laboratorios=="4"]); sc5<-sd(C[Laboratorios=="5"]); sc6<-sd(C[Laboratorios=="6"]); sc7<-sd(C[Laboratorios=="7"]); sc8<-sd(C[Laboratorios=="8"])

sd1<-sd(D[Laboratorios=="1"]); sd2<-sd(D[Laboratorios=="2"]); sd3<-sd(D[Laboratorios=="3"]); sd4<-sd(D[Laboratorios=="4"]); sd5<-sd(D[Laboratorios=="5"]); sd6<-sd(D[Laboratorios=="6"]); sd7<-sd(D[Laboratorios=="7"]); sd8<-sd(D[Laboratorios=="8"])

se1<-sd(E[Laboratorios=="1"]); se2<-sd(E[Laboratorios=="2"]); se3<-sd(E[Laboratorios=="3"]); se4<-sd(E[Laboratorios=="4"]); se5<-sd(E[Laboratorios=="5"]); se6<-sd(E[Laboratorios=="6"]); se7<-sd(E[Laboratorios=="7"]); se8<-sd(E[Laboratorios=="8"])


s_i<-data.frame(cbind("A"=c(sa1,sa2,sa3,sa4,sa5,sa6,sa7,sa8),"B"=c(sb1,sb2,sb3,sb4,sb5,sb6,sb7,sb8),"C"=c(sc1,sc2,sc3,sc4,sc5,sc6,sc7,sc8),"D"=c(sd1,sd2,sd3,sd4,sd5,sd6,sd7,sd8),"E"=c(se1,se2,se3,se4,se5,se6,se7,se8)));s_i



###################### Diferencia medias individuales - medias generales (y-m) #########################

diferencia_medias<-data.frame(cbind("A"=c(a1-mean(A),a2-mean(A),a3-mean(A),a4-mean(A),a5-mean(A),a6-mean(A),a7-mean(A),a8-mean(A)),"B"=c(b1-mean(B),b2-mean(B),b3-mean(B),b4-mean(B),b5-mean(B),b6-mean(B),b7-mean(B),b8-mean(B)),"C"=c(c1-mean(C),c2-mean(C),c3-mean(C),c4-mean(C),c5-mean(C),c6-mean(C),c7-mean(C),c8-mean(C)),"D"=c(d1-mean(D),d2-mean(D),d3-mean(D),d4-mean(D),d5-mean(D),d6-mean(D),d7-mean(D),d8-mean(D)),"E"=c(e1-mean(E),e2-mean(E),e3-mean(E),e4-mean(E),e5-mean(E),e6-mean(E),e7-mean(E),e8-mean(E))));diferencia_medias


###################### Desv. t�?pica diferencia medias (s_m) #########################

desv_a=sqrt(((a1-mean(A))^2+(a2-mean(A))^2+(a3-mean(A))^2+(a4-mean(A))^2+(a5-mean(A))^2+(a6-mean(A))^2+(a7-mean(A))^2+(a8-mean(A))^2)/(8-1))
desv_b=sqrt(((b1-mean(B))^2+(b2-mean(B))^2+(b3-mean(B))^2+(b4-mean(B))^2+(b5-mean(B))^2+(b6-mean(B))^2+(b7-mean(B))^2+(b8-mean(B))^2)/(8-1))
desv_c=sqrt(((c1-mean(C))^2+(c2-mean(C))^2+(c3-mean(C))^2+(c4-mean(C))^2+(c5-mean(C))^2+(c6-mean(C))^2+(c7-mean(C))^2+(c8-mean(C))^2)/(8-1))
desv_d=sqrt(((d1-mean(D))^2+(d2-mean(D))^2+(d3-mean(D))^2+(d4-mean(D))^2+(d5-mean(D))^2+(d6-mean(D))^2+(d7-mean(D))^2+(d8-mean(D))^2)/(8-1))
desv_e=sqrt(((e1-mean(E))^2+(e2-mean(E))^2+(e3-mean(E))^2+(e4-mean(E))^2+(e5-mean(E))^2+(e6-mean(E))^2+(e7-mean(E))^2+(e8-mean(E))^2)/(8-1))

s_m=data.frame(cbind("A"=desv_a,"B"=desv_b,"C"=desv_c,"D"=desv_d,"E"=desv_e));s_m



############################# Desv. T�?pica Repetibilidad (s_r) #############################

rep_a<-sqrt((sa1^2+sa2^2+sa3^2+sa4^2+sa5^2+sa6^2+sa7^2+sa8^2)/8)
rep_b<-sqrt((sb1^2+sb2^2+sb3^2+sb4^2+sb5^2+sb6^2+sb7^2+sb8^2)/8)
rep_c<-sqrt((sc1^2+sc2^2+sc3^2+sc4^2+sc5^2+sc6^2+sc7^2+sc8^2)/8)
rep_d<-sqrt((sd1^2+sd2^2+sd3^2+sd4^2+sd5^2+sd6^2+sd7^2+sd8^2)/8)
rep_e<-sqrt((se1^2+se2^2+se3^2+se4^2+se5^2+se6^2+se7^2+se8^2)/8)

s_r<-data.frame(cbind("A"=rep_a,"B"=rep_b,"C"=rep_c,"D"=rep_d,"E"=rep_e));s_r

############################# Desv. T�?pica Reproduciblidad (s_R) #############################

repr_a=sqrt(desv_a^2+(rep_a^2)*((3-1)/3))
repr_b=sqrt(desv_b^2+(rep_b^2)*((3-1)/3))
repr_c=sqrt(desv_c^2+(rep_c^2)*((3-1)/3))
repr_d=sqrt(desv_d^2+(rep_d^2)*((3-1)/3))
repr_e=sqrt(desv_e^2+(rep_e^2)*((3-1)/3))

s_R=data.frame(cbind("A"=repr_a,"B"=repr_b,"C"=repr_c,"D"=repr_d,"E"=repr_e));s_R

################################### Estad�?stico h ###################################

ha1=(a1-mean(A))/desv_a;ha2=(a2-mean(A))/desv_a;ha3=(a3-mean(A))/desv_a;ha4=(a4-mean(A))/desv_a;ha5=(a5-mean(A))/desv_a;ha6=(a6-mean(A))/desv_a;ha7=(a7-mean(A))/desv_a;ha8=(a8-mean(A))/desv_a

hb1=(b1-mean(B))/desv_b;hb2=(b2-mean(B))/desv_b;hb3=(b3-mean(B))/desv_b;hb4=(b4-mean(B))/desv_b;hb5=(b5-mean(B))/desv_b;hb6=(b6-mean(B))/desv_b;hb7=(b7-mean(B))/desv_b;hb8=(b8-mean(B))/desv_b

hc1=(c1-mean(C))/desv_c;hc2=(c2-mean(C))/desv_c;hc3=(c3-mean(C))/desv_c;hc4=(c4-mean(C))/desv_c;hc5=(c5-mean(C))/desv_c;hc6=(c6-mean(C))/desv_c;hc7=(c7-mean(C))/desv_c;hc8=(c8-mean(C))/desv_c

hd1=(d1-mean(D))/desv_d;hd2=(d2-mean(D))/desv_d;hd3=(d3-mean(D))/desv_d;hd4=(d4-mean(D))/desv_d;hd5=(d5-mean(D))/desv_d;hd6=(d6-mean(D))/desv_d;hd7=(d7-mean(D))/desv_d;hd8=(d8-mean(D))/desv_d

he1=(e1-mean(E))/desv_e;he2=(e2-mean(E))/desv_e;he3=(e3-mean(E))/desv_e;he4=(e4-mean(E))/desv_e;he5=(e5-mean(E))/desv_e;he6=(e6-mean(E))/desv_e;he7=(e7-mean(E))/desv_e;he8=(e8-mean(E))/desv_e

h=data.frame(cbind("A"=c(ha1,ha2,ha3,ha4,ha5,ha6,ha7,ha8),"B"=c(hb1,hb2,hb3,hb4,hb5,hb6,hb7,hb8),"C"=c(hc1,hc2,hc3,hc4,hc5,hc6,hc7,hc8),"D"=c(hd1,hd2,hd3,hd4,hd5,hd6,hd7,hd8),"E"=c(he1,he2,he3,he4,he5,he6,he7,he8)));h

############ H_cr�?tico

h_critico=(7*qt(0.0025,6,lower.tail=F))/sqrt(8*((qt(0.0025,6,lower.tail=F))^2+6));h_critico #2.15

############ Gráficamente

windows()
barplot(c(ha1,hb1,hc1,hd1,he1,0,0,ha2,hb2,hc2,hd2,he2,0,0,ha3,hb3,hc3,hd3,he3,0,0,ha4,hb4,hc4,hd4,he4,0,0,ha5,hb5,hc5,hd5,he5,0,0,ha6,hb6,hc6,hd6,he6,0,0,ha7,hb7,hc7,hd7,he7,0,0,ha8,hb8,hc8,hd8,he8),col=c("Red","Lightblue","Purple","Orange","Lightgreen","Black","Black"),ylim=c(-3,3),main="Estad?stico h",xlab="Laboratorios",ylab="Nivel de Concentraci?n")
abline(h=c(-2.152492,2.152492),col="Red")
nombres.filas=c("A","B","C","D","E")
legend("topright",nombres.filas,fill=c("Red","Lightblue","Purple","Orange","Lightgreen"),cex=0.8)
text(3,-1,"1",font=2);text(11,-1,"2",font=2);text(20,-1,"3",font=2);text(29,-1,"4",font=2);text(37,-1,"5",font=2);text(46,-1,"6",font=2);text(53,-1,"7",font=2);text(62,-1,"8",font=2)


################################### Estad?stico k ###################################

ka1=sa1/rep_a;ka2=sa2/rep_a;ka3=sa3/rep_a;ka4=sa4/rep_a;ka5=sa5/rep_a;ka6=sa6/rep_a;ka7=sa7/rep_a;ka8=sa8/rep_a
kb1=sb1/rep_b;kb2=sb2/rep_b;kb3=sb3/rep_b;kb4=sb4/rep_b;kb5=sb5/rep_b;kb6=sb6/rep_b;kb7=sb7/rep_b;kb8=sb8/rep_b
kc1=sc1/rep_c;kc2=sc2/rep_c;kc3=sc3/rep_c;kc4=sc4/rep_c;kc5=sc5/rep_c;kc6=sc6/rep_c;kc7=sc7/rep_c;kc8=sc8/rep_c
kd1=sd1/rep_d;kd2=sd2/rep_d;kd3=sd3/rep_d;kd4=sd4/rep_d;kd5=sd5/rep_d;kd6=sd6/rep_d;kd7=sd7/rep_d;kd8=sd8/rep_d
ke1=se1/rep_e;ke2=se2/rep_e;ke3=se3/rep_e;ke4=se4/rep_e;ke5=se5/rep_e;ke6=se6/rep_e;ke7=se7/rep_e;ke8=se8/rep_e

k=data.frame(cbind("A"=c(ka1,ka2,ka3,ka4,ka5,ka6,ka7,ka8),"B"=c(kb1,kb2,kb3,kb4,kb5,kb6,kb7,kb8),"C"=c(kc1,kc2,kc3,kc4,kc5,kc6,kc7,kc8),"D"=c(kd1,kd2,kd3,kd4,kd5,kd6,kd7,kd8),"E"=c(ke1,ke2,ke3,ke4,ke5,ke6,ke7,ke8)));k

######### K_critico

k_critico=sqrt(8/(1+(7/qf(0.995,2,14))));k_critico

######### Gráficamente

windows()
barplot(c(ka1,kb1,kc1,kd1,ke1,0,0,ka2,kb2,kc2,kd2,ke2,0,0,ka3,kb3,kc3,kd3,ke3,0,0,ka4,kb4,kc4,kd4,ke4,0,0,ka5,kb5,kc5,kd5,ke5,0,0,ka6,kb6,kc6,kd6,ke6,0,0,ka7,kb7,kc7,kd7,ke7,0,0,ka8,kb8,kc8,kd8,ke8),col=c("Red","Lightblue","Purple","Orange","Lightgreen","Black","Black"),ylim=c(0,3),main="Estad?stico k",xlab="Laboratorios",ylab="Nivel de Concentraci?n")
abline(h=c(2.06084),col="Red")
nombres.filas=c("A","B","C","D","E")
legend("topright",nombres.filas,fill=c("Red","Lightblue","Purple","Orange","Lightgreen"),cex=0.8)
text(3,1.5,"1",font=2);text(11,1.5,"2",font=2);text(20,1.5,"3",font=2);text(30,1.5,"4",font=2);text(37,1.5,"5",font=2);text(46,1.5,"6",font=2);text(53,1.5,"7",font=2);text(62,1.5,"8",font=2)

############################# Precisi?n y l?mites (r y R) #############################

# L�?mites r:
ra=2.8*rep_a;rb=2.8*rep_b;rc=2.8*rep_c;rd=2.8*rep_d;re=2.8*rep_e

# L?mites R:
Ra=2.8*repr_a;Rb=2.8*repr_b;Rc=2.8*repr_c;Rd=2.8*repr_d;Re=2.8*repr_e

m=c(mean(A),mean(B),mean(C),mean(D),mean(E))

precision=data.frame("Nivel"=c("A","B","C","D","E"),"m"=m,"Sr"=c(rep_a,rep_b,rep_c,rep_d,rep_e),"SR"=c(repr_a,repr_b,repr_c,repr_d,repr_e),"r"=c(ra,rb,rc,rd,re),"R"=c(Ra,Rb,Rc,Rd,Re));precision


#----------------------------------------------------------------------#
#-- INTERLABORATORIOS con el paquete ILS ------------------------------#
#----------------------------------------------------------------------#

# Gr�ficos para el estad�stico h de Mandel:

library(ILS)
data(Glucose)
Glucose.qcd <- lab.qcd(Glucose)
str(Glucose.qcd)
h<- h.qcs(Glucose.qcd, alpha = 0.005)
summary(h)
plot(h)

# Gr�ficos para el estad�stico k de Mandel:

library(ILS)
data(Glucose)
Glucose.qcd <- lab.qcd(Glucose)
str(Glucose.qcd)
k<- k.qcs(Glucose.qcd, alpha = 0.005)
summary(k)
plot(k)



#-----------------------------------------------------------------------------#

#-----------------------------------------------------------------------------#
# 5. EJEMPLOS Y CASOS PR�CTICOS DE APLICACI�N DE T�CNICAS DE DOE       -------# 
#-----------------------------------------------------------------------------#

library(MASS)
library(ISLR)
### Simple linear regression
names(Boston)
?Boston
plot(medv~lstat,Boston)
fit1=lm(medv~lstat,data=Boston)
fit1
summary(fit1)
abline(fit1,col="red")
names(fit1)
confint(fit1)
predict(fit1,data.frame(lstat=c(5,10,15)),interval="confidence")
### Multiple linear regression
fit2=lm(medv~lstat+age,data=Boston)
summary(fit2)
fit3=lm(medv~.,Boston)
summary(fit3)
par(mfrow=c(2,2))
plot(fit3)
fit4=update(fit3,~.-age-indus)
summary(fit4)
### Nonlinear terms and Interactions
fit5=lm(medv~lstat*age,Boston)
summary(fit5)
fit6=lm(medv~lstat +I(lstat^2),Boston); summary(fit6)
attach(Boston)
par(mfrow=c(1,1))
plot(medv~lstat)
points(lstat,fitted(fit6),col="red",pch=20)
fit7=lm(medv~poly(lstat,4))
points(lstat,fitted(fit7),col="blue",pch=20)
plot(1:20,1:20,pch=1:20,cex=2)
###Qualitative predictors
fix(Carseats)
names(Carseats)
summary(Carseats)
fit1=lm(Sales~.+Income:Advertising+Age:Price,Carseats)
summary(fit1)
contrasts(Carseats$ShelveLoc)
###Writing R functions
regplot=function(x,y){
  fit=lm(y~x)
  plot(x,y)
  abline(fit,col="red")
}
attach(Carseats)
regplot(Price,Sales)
regplot=function(x,y,...){
  fit=lm(y~x)
  plot(x,y,...)
  abline(fit,col="red")
}
regplot(Price,Sales,xlab="Price",ylab="Sales",col="blue",pch=20)

## EJEMPLOS DEL LIBRO PASWR
## Practices whith R: Ugarte, M.D., Militino, A. and Alan T. A. (2008).
## Probability and Statistics with R.    
## http://www1.appstate.edu/~arnholta/PASWR/index.htm

library(PASWR)
attach(Tire)
oneway.plots(StopDist,tire)
?Tire

repeticion<-rep(seq(1:6),4)
xtabs(StopDist~tire+repeticion,data=Tire)

mod.aov<-aov(StopDist~tire, data = Tire)
summary(mod.aov)

## Similar lm a aov:

mod.lm <- lm(StopDist~tire, data=Tire)
anova(mod.lm)

## The p-value for the test is P(F3, 20 = 5.33) = 0.007.

pf(5.33, 3, 20, lower.tail=FALSE)

model.tables(mod.aov, type="means")

model.tables(mod.aov, type="effects")

power.t.test(n=6,delta=15,sd=10,alternative="one.sided")

EDA(rstandard(mod.aov)) # Exploratory Data Analysis

library(car)
leveneTest(mod.aov) # Levene Test for homogeneity of variance

## Tukey?s Honestly Significant Difference

CI <- TukeyHSD(mod.aov, which="tire")
CI
################################################################################
## Chapter 11
## January 21, 2009
## Alan T. Arnholt
options(width=65)
library(PASWR)
################################################################################
# Motivational Example: Tires
population <- rep(LETTERS[1:4],6)
Treatment <- sample(population)
datf <- data.frame(Run=1:24,Treatment)
datf[1:5,]
#
attach(Tire)
oneway.plots(StopDist, tire)
detach(Tire)
################################################################################
# Example 11.1
attach(Tire)
TreatmentMean <- tapply(StopDist,tire,mean)
TreatmentMean
a <- length(TreatmentMean)
N <- length(StopDist)
dft <- a-1
dfe <- N-a
GrandMean <- mean(StopDist)
GrandMean
SStreat <- 6*sum((TreatmentMean-GrandMean)^2)
SStreat
SStotal <- sum((StopDist - GrandMean)^2)
SStotal
SSerror <- SStotal - SStreat
SSerror
MStreat <- SStreat/dft
MStreat
MSerror <- SSerror/dfe
MSerror
Fobs <- MStreat/MSerror
Fobs
pvalue <- 1-pf(Fobs,3,20)
pvalue
summary(aov(StopDist~tire))
#
model.tables(aov(StopDist~tire),type="means")
detach(Tire)
################################################################################
# Example 11.2
# part a.
MEANS <- c(405,390)
a <- length(MEANS)
n <- 6
N <- a*n
dfe <- N-a
SD <- 10
alpha <- .05
Y <- rep(MEANS,rep(n,a))
treat <- factor(rep(1:a,rep(n,a)))
SStreat <- summary(aov(Y~treat))[[1]][1,2]
lambda <- SStreat/SD^2
Gamma <- sqrt(lambda)
Gamma
cv <- qt(1-alpha,dfe)
Power <- 1-pt(cv,dfe,ncp=Gamma)
Power
#
power.t.test(n=6,delta=15,sd=10,alternative="one.sided")
################################################################################
# part b.
### Sampling Distribution of MST/MSE
set.seed(10)
sims <- 10000       # number of simulations
n1 <- 6; n2 <- 6; n3 <- 6; n4 <- 6
a <- 4              # number of treatments
N <- n1+n2+n3+n4
df.treat <- a - 1   # dof treatment
df.error <- N - a   # dof error
alpha <- 0.05       # alpha level
### Normal Distribution
mu1 <- 390; sig1 <- 20 # pop1 mean and sigma
mu2 <- 405; sig2 <- 20 # pop2 mean and sigma
mu3 <- 415; sig3 <- 20 # pop3 mean and sigma
mu4 <- 410; sig4 <- 20 # pop4 mean and sigma
t1 <- matrix(rnorm(sims*n1,mu1,sig1),nrow=sims,byrow=TRUE)
t2 <- matrix(rnorm(sims*n2,mu2,sig2),nrow=sims,byrow=TRUE)
t3 <- matrix(rnorm(sims*n3,mu3,sig3),nrow=sims,byrow=TRUE)
t4 <- matrix(rnorm(sims*n4,mu4,sig4),nrow=sims,byrow=TRUE)
MUS <- c(mu1,mu2,mu3,mu4)
MUB <- mean(MUS)
lambda <-(n1*(mu1-MUB)^2 + n2*(mu2-MUB)^2 + n3*(mu3-MUB)^2 +
            n4*(mu4-MUB)^2)/(sig1^2)
mt1 <- apply(t1,1,mean)
mt2 <- apply(t2,1,mean)
mt3 <- apply(t3,1,mean)
mt4 <- apply(t4,1,mean)
##############################################################################
mmean <- cbind(mt1,mt2,mt3,mt4)
TT <- cbind(t1,t2,t3,t4)
gm <- apply(TT,1,mean)
SStreat <- n1*((mt1-gm)^2) + n2*((mt2-gm)^2) + n3*((mt3-gm)^2) +
  n4*((mt4-gm)^2)
JU2 <- (TT - gm)^2
SStotal <- apply(JU2,1,sum)
SSerror <- SStotal - SStreat
Fobs <- (SStreat/df.treat)/(SSerror/df.error)
q995 <- quantile(Fobs,.995)
##############################################################################
# Figure 11.5
hist(Fobs,col="pink",prob=TRUE,breaks="Scott",main="",xlim=c(0,q995))
title(main="Simulated Sampling Distribution")
curve(df(x,df.treat,df.error,lambda),0,q995,col="red",
      add=TRUE,lwd=3)   # only R
val <- c(.80,.85,.90,.95,.99)
Theoretical <- qf(val,df.treat,df.error,lambda)
Simulated <- quantile(Fobs,val)
SimSigLev <- c( sum(Fobs>Theoretical[1])/sims,
                sum(Fobs>Theoretical[2])/sims,
                sum(Fobs>Theoretical[3])/sims,
                sum(Fobs>Theoretical[4])/sims,
                sum(Fobs>Theoretical[5])/sims )
TheSigLev <- 1-val
ANS <- rbind(Theoretical,Simulated,TheSigLev,SimSigLev)
round(ANS,4)
################################################################################
Simulated.Power <- sum(Fobs > qf(1-alpha,df.treat,df.error))/sims
Simulated.Power
####
MEANS <- c(390,405,415,410)
a <- length(MEANS)
n <- 6
N <- a*n
SD <- 20
alpha <- .05
Y <- rep(MEANS,rep(n,a))
treat <- factor(rep(1:a,rep(n,a)))
SStreat <- summary(aov(Y~treat))[[1]][1,2] # For R
# SStreat <- summary(aov(Y~treat))[1,2] # For S-PLUS
lambda <- SStreat/SD^2
lambda
cv <- qf(1-alpha,a-1,N-a)
Power <- 1-pf(cv,a-1,N-a,ncp=lambda)
Power
#
power.anova.test(groups=a,n=n, between.var=var(MEANS),within.var=SD^2)
# part c.
MEANS <- c(390,405,415,410)
a <- length(MEANS)
n <- 6
N <- a*n
SD <- 10
alpha <- .05
Y <- rep(MEANS,rep(n,a))
treat <- factor(rep(1:a,rep(n,a)))
SStreat <- summary(aov(Y~treat))[[1]][1,2] # For R
# SStreat <- summary(aov(Y~treat))[1,2] # For S-Plus
lambda <- SStreat/SD^2
lambda
cv <- qf(1-alpha,a-1,N-a)
Power <- 1-pf(cv,a-1,N-a,ncp=lambda)
Power
# Or
SD <- 10
power.anova.test(groups=a,n=n, between.var=var(MEANS),within.var=SD^2)
# part d.
SD <- 20
Powerr <- 0
nr <- 1
MEANS <- c(390,405,415,410)
a <- length(MEANS)
while(Powerr < .80)
{
  nr <- nr+1
  Nr <- a*nr
  alpha <- .05
  Yr <- rep(MEANS,rep(nr,a))
  treatr <- factor(rep(1:a,rep(nr,a)))
  SStreatr <- summary(aov(Yr~treatr))[[1]][1,2] # R
  # SStreatr <- summary(aov(Yr~treatr))[1,2] # S-PLUS
  lambdar <- SStreatr/SD^2
  cvr <- qf(1-alpha,a-1,Nr-a)
  Powerr <- 1-pf(cvr,a-1,Nr-a,ncp=lambdar)
}
c(nr,lambdar,Powerr)
# Or
power.anova.test(groups=4, power=.80,
                 between.var=var(MEANS), within.var=20^2)
#
nrf <- ceiling(power.anova.test(groups=4,power=.80,
                                between.var=var(MEANS),within.var=20^2)$n)
nrf
# part e.
MEANS <- c(390,405,415,410)
SD <- 14
a <- length(MEANS)
n1=6; n2=6; n3=12; n4=12;
N <- n1+n2+n3+n4
alpha <- .05
Y <- rep(MEANS,c(n1,n2,n3,n4))
treat <- factor(rep(1:a,c(n1,n2,n3,n4)))
SStreat <- summary(aov(Y~treat))[[1]][1,2] # R
# SStreat <- summary(aov(Y~treat))[1,2] # S-PLUS
lambda <- SStreat/SD^2
lambda
cv <- qf(1-alpha,a-1,N-a)
Power <- 1-pf(cv,a-1,N-a,ncp=lambda)
Power
################################################################################
# Checking for Independence of Errors
# Figure 11.7
attach(Tire)
par(pty="s")
mod.aov <- aov(StopDist~tire)
library(MASS)
r <- stdres(mod.aov)
n <- length(StopDist)
plot(1:n,r,ylab="Standardized Residual",xlab="Ordered Value")
detach(Tire)

################################################################################
# Checking for Normality of Errors
# Figure 11.8
attach(Tire)
mod.aov <- aov(StopDist~tire)
library(MASS)
r <- stdres(mod.aov)
par(pty="s")
qqnorm(r)
abline(a=0,b=1)
shapiro.test(r)
detach(Tire)
################################################################################
# Checking for Constant Variance
attach(Tire)
mod.aov <- aov(StopDist~tire)
library(MASS)
r <- stdres(mod.aov)
tm <- fitted(mod.aov)
plot(tm,r,xlab="Fitted Value",ylab="Standardized Residual")
med <- tapply(StopDist,tire,median)
ZIJ <- abs(StopDist-med[tire])
summary(aov(ZIJ~tire))
checking.plots(mod.aov)
detach(Tire)
################################################################################
# Example 11.3
attach(FCD)
FCD.aov <- aov(Weight~Diet)
# Figure 11.12
checking.plots(FCD.aov)
# Figure 11.13
library(MASS)
boxcox(FCD.aov)
detach(FCD)
# Welch's Test
attach(FCD)
ni <- tapply(Weight,Diet,length)
a <- length(ni)
si2 <- tapply(Weight,Diet,var)
wi <- ni/si2
yb <- tapply(Weight,Diet,mean)
ytild <- sum(wi*yb)/sum(wi)
wlamb <- 3*sum((1 - (wi/sum(wi)))^2 / (ni-1) )/(a^2-1)
dfn <- (a-1)
dfd <- 1/wlamb
W <- sum(wi*(yb-ytild)^2/(3-1)) / (1 + 2/3*(3-2)*wlamb)
W
pvalue <- 1-pf(W,dfn,dfd)
pvalue
oneway.test(Weight~Diet)
detach(FCD)
################################################################################
# Example 11.4
attach(Drosophila)
summary(aov(Fecundity~Line))
#
checking.plots(aov(Fecundity~Line))
#
MSE <- summary(aov(Fecundity~Line))[[1]][2,3] #Remove [[1]] for S-PLUS
SSTreat <- summary(aov(Fecundity~Line))[[1]][1,2] # [[1]] for R
ybari <- tapply(Fecundity,Line,mean)
dfe <- 75-3
ni <- c(25,25,25)
ci <- c(1,-.5,-.5)
di <- c(0,1,-1)
ORTHO <- sum(ci*di/ni) # verify orthogonality
ORTHO
SSC1 <- (sum(ci*ybari))^2/sum((ci^2/ni))
SSC2 <- (sum(di*ybari))^2/sum((di^2/ni))
OSSC <- c(SSC1,SSC2)
c(SSC1,SSC2,SSC1+SSC2,SSTreat)
FC1 <- SSC1/MSE
FC2 <- SSC2/MSE
Fs <-c(FC1,FC2)
pval <- 1-pf(Fs,1,dfe)
cbind(OSSC,Fs,pval)
contrasts(Line)[,1]<- ci
contrasts(Line)[,2]<- di
CO <- contrasts(Line)
colnames(CO) <- c("C1","C2")
CO
summary(aov(Fecundity~C(Line,CO,1)+C(Line,CO,2)))
#
contrasts(Line) <- contr.treatment(levels(Line)) # R defaults
contrasts(Line)
# Helmert contrasts
contrasts(Line) <- contr.helmert(levels(Line))
contrasts(Line)
# 
contrasts(Line) <- contr.helmert(levels(Line))[3:1,2:1]
contrasts(Line)
#
CO <- contrasts(Line)
colnames(CO) <- c("Contrast 1","Contrast 2")
CO
summary(aov(Fecundity~C(Line,CO,1)+C(Line,CO,2)))
# Simultaneous p-values
library(multcomp)
summary(glht(aov(Fecundity~Line), linfct = mcp(Line = t(CO))))
CI <- confint(glht(aov(Fecundity~Line), linfct = mcp(Line = t(CO))))
CI
#
##############
# Some Code for Figure 11.15
library(gregmisc)
par(mfrow=c(2,2),mgp=c(3,2,0),pty="m")  # Making room for labels
# All means with 95% CIs
MEANS <- tapply(Fecundity,Line,mean)
mod.dro <- aov(Fecundity~Line)
MSE <- summary(mod.dro)[[1]][2,3]
NS <- tapply(Fecundity,Line,length)
SE <- sqrt(MSE)/sqrt(NS)
t.v <- qt(.975,sum(NS)-length(NS))
ci.l <- MEANS - t.v*SE
ci.u <- MEANS + t.v*SE
barplot2(MEANS,plot.ci=T,ci.l=ci.l,ci.u=ci.u,col="skyblue",
         ylim=c(0,40),ci.lwd=2)
title(main="Means with 95% CIs")
# Contrast 1
MEANS <- c(mean(Fecundity[Line=="Nonselected"]),
           mean(Fecundity[Line=="Resistant"|Line=="Susceptible"]))
NS <- c(length(Fecundity[Line=="Nonselected"]),
        length(Fecundity[Line=="Resistant"|Line=="Susceptible"]))
SE <- sqrt(MSE)/sqrt(NS)
t.v <- qt(.975,sum(NS)-length(NS))
ci.l <- MEANS - t.v*SE
ci.u <- MEANS + t.v*SE
NAMES <- c(expression(hat(mu)[{Nonselected}]),expression(frac(hat(mu)[{Resistant}]+hat(mu)[{Selected}],2)))
barplot2(MEANS,plot.ci=T,ci.l=ci.l,ci.u=ci.u,col="skyblue",names.arg=NAMES,
         ylim=c(0,40),ci.lwd=2)
title(main="Individual 95% CIs \n (Contrast 1)")
# Contrast 2
MEANS <- tapply(Fecundity,Line,mean)
mod.dro <- aov(Fecundity~Line)
MSE <- summary(mod.dro)[[1]][2,3]
NS <- tapply(Fecundity,Line,length)
SE <- sqrt(MSE)/sqrt(NS[2:3])
t.v <- qt(.975,sum(NS)-length(NS))
ci.l <- MEANS[2:3] - t.v*SE[1:2]
ci.u <- MEANS[2:3] + t.v*SE[1:2]
NAMES <- c(expression(hat(mu)[{Resistant}]),expression(hat(mu)[{Susceptible}]))
barplot2(MEANS[2:3],plot.ci=T,ci.l=ci.l,ci.u=ci.u,col="skyblue",
         names.arg=NAMES,ylim=c(0,40),ci.lwd=2)
title(main="Individual 95% CIs \n (Contrast 2)")
par(mgp=c(3,1,0))
# Simultaneous CI
library(multcomp)
CI <- confint(glht(aov(Fecundity~Line), linfct = mcp(Line = t(CO))))
plot(CI)
par(mfrow=c(1,1))
# name: BARPLOTci.ps
detach(Drosophila)
################################################################################
# Example 11.5
attach(Tire)
CI <- TukeyHSD(aov(StopDist~tire),which="tire")
CI
# Figure 11.16
plot(CI,las=1)
#
library(multcompView)
# Figure 11.17
multcompBoxplot(StopDist~tire,data=Tire)
# Code to compute LSD, BSD, HSD, and Scheffe statistics
tire.aov <- aov(StopDist~tire)
alpha.c <- 0.05
summary(tire.aov)
MSE <- summary(aov(tire.aov))[[1]][2,3] # For R
ybari <- tapply(StopDist,tire,mean)
a <- length(ybari)
N <- length(StopDist)
dfe <- N-a
sort(ybari)
TcritLSD <- qt(1-alpha.c/2,dfe)
LSD <- TcritLSD*sqrt(MSE)*sqrt(2/6)
TcritBON <- qt(1-alpha.c/(choose(a,2)*2),dfe)
BON <- TcritBON*sqrt(MSE)*sqrt(2/6)
TcritTUK <- qtukey(1 - alpha.c,a,dfe)/sqrt(2)
HSD <- TcritTUK*sqrt(MSE)*sqrt(2/6)
CSF <- sqrt((a-1)*qf(1-alpha.c,a-1,dfe))
SCH <- CSF*sqrt(MSE*2/6)
c(LSD,BON,HSD,SCH)
outer(sort(ybari),sort(ybari),"-")
#
# Figure 11.18
library(gregmisc)
NS <- tapply(StopDist,tire,length)
SE <- sqrt(MSE)/sqrt(NS)
t.v <- qt(.975,dfe)
ci.l <- ybari - t.v*SE
ci.u <- ybari + t.v*SE
barplot2(ybari,plot.ci=TRUE,ci.l=ci.l,ci.u=ci.u,col="skyblue",
         ylim=c(0,450),ci.lwd=2)
title(main="Mean Stoppping Distance by Tire \n with Individual 95% CIs")
detach(Tire)
################################################################################
# Example 11.6
attach(food)
summary(aov(shear~freezer))
MSC <- summary(aov(shear~freezer))[[1]][1,3] # omit [[1]] for S-PLUS
MSE <- summary(aov(shear~freezer))[[1]][2,3] # omit [[1]] for S-PLUS
sig2tau <- (MSC-MSE)/4
sig2tau
detach(food)
################################################################################
# Randomized Complete Block Design - Sampling Plan
car <- rep(c("Car1","Car2","Car3","Car4"),c(4,4,4,4))
tire <- rep(LETTERS[1:4],c(4,4,4,4))
tireCRD <- sample(tire)
tireCRBD <- c(sample(LETTERS[1:4]),sample(LETTERS[1:4]),
              sample(LETTERS[1:4]),sample(LETTERS[1:4]))
Designs <- cbind(car,tire,tireCRD,tireCRBD)
Designs
################################################################################
# Example 11.7
# Figure 11.19
attach(TireWear)
par(mfrow=c(1,2), cex=.8)
interaction.plot(Treat,Block,Wear, type="b", legend=FALSE)
interaction.plot(Block,Treat,Wear, type="b", legend=FALSE)
par(mfrow=c(1,1), cex=1)
# Figure 11.20
library(lattice) # R
A <- stripplot(Treat~Wear|Block,layout=c(4,1))
B <- stripplot(Block~Wear|Treat,layout=c(4,1))
print(A,split=c(1,1,1,2),more=TRUE)
print(B,split=c(1,2,1,2),more=FALSE)
# Figure 11.21
plot.design(Wear~Treat+Block)
# part b.
mod.aov <- aov(Wear~Treat+Block)
summary(mod.aov)
# part c.
yidotbar <- tapply(Wear,Treat,mean)
ydotjbar <- tapply(Wear,Block,mean)
gm <- mean(Wear)
taui <- yidotbar - gm
blockj <- ydotjbar - gm
GM <- matrix(rep(gm,16),nrow=4)
GM
treatm <- matrix(rep(taui,4),nrow=4,byrow=FALSE)
treatm
blockm <- matrix(rep(blockj,4),nrow=4,byrow=TRUE)
blockm
residm <- matrix(resid(aov(Wear~Treat+Block)),
                 nrow=4,byrow=FALSE)
residm
GM+treatm+blockm+residm
# Or one might use proj()
proj(mod.aov)
# part d.
checking.plots(mod.aov)
# part e.
CI <- TukeyHSD(mod.aov,which="Treat")
CI
# Figure 11.23
plot(CI, las=1)
# Figure 11.24
library(gregmisc)
ybari <- tapply(Wear,Treat,mean)
NS <- tapply(Wear,Treat,length)
MSE <- summary(mod.aov)[[1]][3,3]
SE <- sqrt(MSE)/sqrt(NS)
t.v <- qt(.975,9)
ci.l <- ybari - t.v*SE
ci.u <- ybari + t.v*SE
barplot2(ybari,plot.ci=T,ci.l=ci.l,ci.u=ci.u,col="skyblue",ci.lwd=2)
title(main="Mean Wear by Tire \n with Individual 95% CIs")
# name wearBARPLOT.ps
detach(TireWear)
################################################################################
# Example 11.8
# part a.
Microamps <- c(280,290,285,300,310,295,270,285,290,230,
               235,240,260,240,235,220,225,230)
Glass <- factor(c(rep("Glass I",9),rep("Glass II",9)))
Phosphor <- factor(rep(rep(c(rep("Phosphor A",3),
                             rep("Phosphor B",3),rep("Phosphor C",3)),2)))
# part b.  The data is examined with the function twoway.plots()
# Figure 11.25
twoway.plots(Microamps,Glass,Phosphor)
# part c.
mod.TVB <- aov(Microamps ~ Glass + Phosphor + Glass:Phosphor)
model.tables(mod.TVB,type="means")
#
model.tables(mod.TVB,type="effects")
# part d.
anova(mod.TVB)
# part e.
checking.plots(mod.TVB)
# part f.
# Figure 11.27
par(mfrow=c(1,2),pty="s")
interaction.plot(Glass,Phosphor,Microamps,type="b",legend=FALSE)
interaction.plot(Phosphor,Glass,Microamps,type="b",legend=FALSE)
par(mfrow=c(1,1),pty="m")
# part g.
# Figure 11.28
par(mar=c(5.1,10.1,4.1,2.1),cex.axis=.5)
CI <- TukeyHSD(mod.TVB)
plot(CI,las=1)
par(mar=c(5.1,4.1,4.1,2.1),cex.axis=1)
# Figure 11.29
library(gregmisc)
meanM <- tapply(Microamps,list(Glass,Phosphor),mean)
nsM <- tapply(Microamps,list(Glass,Phosphor),length)
MSE <- anova(mod.TVB)[4,3]
t.c <- qt(.975,12)
lci <- meanM - t.c*sqrt(MSE/nsM)
uci <- meanM + t.c*sqrt(MSE/nsM)
barplot2(meanM,beside=TRUE,legend=TRUE,ylim=c(0,400),
         plot.ci=TRUE,ci.l=lci,ci.u=uci,ci.lwd=2,col=c("#A9E2FF","#0080FF"))
title(main="Treatment Means with Individual 95% CIs")
################################################################################

